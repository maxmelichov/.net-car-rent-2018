﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPage : System.Web.UI.MasterPage
{
    
    
    private Customer c;
     protected void Page_Load(object sender, EventArgs e)
    {
        this.c = Session["customer"] as Customer;
        
        SetMenu();
        if (c != null)
        {
            this.lbname.Text = string.Format("Hello {0}", c.CustomerName);
           
        }
        else
            this.lbname.Text = "Hello Guest";
     }
    protected void Image2_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("Store.aspx");
    }

    private void SetMenu()
    {
        if (this.c == null)
        {
            this.NavigationMenu.Items.RemoveAt(7);
            this.NavigationMenu.Items.RemoveAt(5);
            this.NavigationMenu.Items.RemoveAt(2);
            this.NavigationMenu.Items.RemoveAt(3);
        }

        else
        {
            
            if (this.c.Prem != 2)
                this.NavigationMenu.Items.RemoveAt(7);
            this.NavigationMenu.Items.RemoveAt(6);
            this.NavigationMenu.Items.RemoveAt(5);
            this.NavigationMenu.Items.RemoveAt(1);
            
        }
    }
    protected void NavigationMenu_MenuItemClick(object sender, MenuEventArgs e)
    {

    }



  
}
 
 