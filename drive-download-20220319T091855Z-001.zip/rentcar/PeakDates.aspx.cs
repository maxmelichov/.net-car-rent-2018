﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PeakDates : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btadd_Click(object sender, EventArgs e)
    {
        Response.Redirect("Store-1.aspx");
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        

    }
    protected void DropDownList1_SelectedIndexChanged1(object sender, EventArgs e)
    {
        DateTime strat = this.Calendar1.SelectedDate;
        int dur = int.Parse(this.DropDownList1.SelectedValue);
        CarAreaService.AreaService service = new CarAreaService.AreaService();
        CarView car = Session["peakCar"] as CarView;
        bool isavl = service.IsCarAvailableToRent(car.Id, strat, dur);
        if (isavl)
        {
            lberror.Text = "Car Is Available. Please Continue";
            btToStore.Visible = true;
            btToCart.Visible = true;
            car.Duration = dur;
            car.StartDate = strat;
            CartData sal = Session["sal"] as CartData;
            sal.InsertToCart(car);
            Session["peakCar"] = null;
        }

        else
        {
            lberror.Text = "Car Is UnAvailable. Please Peak Different Car";
            btToStore.Visible = true;
            btToCart.Visible = false;
        }
    }
    protected void btToCart_Click(object sender, EventArgs e)
    {
        
        Response.Redirect("Cart.aspx");

    }
}