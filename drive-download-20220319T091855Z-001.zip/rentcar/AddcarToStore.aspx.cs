﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AddcarToStore : System.Web.UI.Page
{
    private int mone = 0;
    private CarAreaService.Car[] cars;
    private int carid = -1;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            CarAreaService.AreaService service = new CarAreaService.AreaService();
            Session["carsArea"] = service.GetAllCarsInfo();

        }

        this.cars = Session["carsArea"] as CarAreaService.Car[];

       if (!IsPostBack)
            LoadCarsModel();

    }


    private void LoadCarsModel()
    {
        this.DropDownList1.Items.Clear();
        this.DropDownList1.DataSource = this.cars;
        this.DropDownList1.DataTextField = "Model";
        this.DropDownList1.DataValueField = "Id";
        this.DropDownList1.DataBind();
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        CarAreaService.Car car = GetSelectedCar(int.Parse(DropDownList1.SelectedValue));
        this.lbid.Text = car.Id.ToString();
        this.lbmodel.Text = car.Model;
        this.lbyear.Text = car.Year.ToString();
        this.lbproducer.Text = car.Producer;
        this.lbav.Text = car.Available.ToString();
        string base64String = Convert.ToBase64String(car.Image, 0, car.Image.Length);

        imgCar.ImageUrl = "data:image/jpeg;base64," + base64String;
        imgCar.Width = Unit.Pixel(200);
        imgCar.Height = Unit.Pixel(200);
        this.Panel1.Visible = true;
        this.GridView1.Visible = false;
        this.btadd.Visible = false; ;
    }

    private CarAreaService.Car GetSelectedCar(int id)
    {
        foreach (CarAreaService.Car car in this.cars)
        {
            if (car.Id == id)
                return car;
        }

        return null;
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        this.Panel1.Visible = false;
        this.Panel2.Visible = true;
        CarAreaService.Car[] cars = Session["carsArea"] as CarAreaService.Car[];
        this.GridView1.DataSource = cars;
        this.GridView1.DataBind();
        this.GridView1.Visible = true; ;
        this.btadd.Visible = true; ;

    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType != DataControlRowType.Header &&
        e.Row.RowType != DataControlRowType.Footer &&
        e.Row.RowType != DataControlRowType.Pager)
        {
            if (e.Row.RowState != (DataControlRowState.Edit | DataControlRowState.Alternate) &&
                e.Row.RowState != (DataControlRowState.Edit | DataControlRowState.Normal))
            {
               
                CarAreaService.Car[] cars = Session["carsArea"] as CarAreaService.Car[];

                CarAreaService.Car car = cars[mone];
                mone++;

                 CheckBox chcarid = (CheckBox)e.Row.Cells[0].FindControl("chcarid");
                 chcarid.ToolTip = car.Id.ToString();

                 System.Web.UI.WebControls.Image carPic = (System.Web.UI.WebControls.Image)e.Row.Cells[6].FindControl("CarImage");

                string base64String = Convert.ToBase64String(car.Image, 0, car.Image.Length);

                carPic.ImageUrl = "data:image/jpeg;base64," + base64String;
                carPic.Width = Unit.Pixel(80);
                carPic.Height = Unit.Pixel(80);

            }
        }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        string s = "";
    }
    protected void GridView1_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {
        string s = "";
    }
    protected void chcarid_CheckedChanged(object sender, EventArgs e)
    {
        CheckBox ch = sender as CheckBox;
        this.carid = int.Parse(ch.ToolTip);
        if (ch.Checked)
        {
            
        
            foreach (GridViewRow row in this.GridView1.Rows)
            {
                CheckBox chcarid = (CheckBox)row.Cells[0].FindControl("chcarid");
                int id = int.Parse(chcarid.ToolTip);
                if (id == this.carid)
                {
                    DropDownList ddlcats = (DropDownList)row.Cells[7].FindControl("ddlcats");
                    ddlcats.Visible = true;
                    TextBox tbprice = (TextBox)row.Cells[8].FindControl("tbprice");
                    tbprice.Visible = true;

                    Category[] cats = Category.GetAllCategories();
                    ddlcats.DataValueField = "CCode";
                    ddlcats.DataTextField = "Cname";
                    ddlcats.DataSource = cats;
                    ddlcats.DataBind();
                    break;

                }
            }
        }

        else
        {
            foreach (GridViewRow row in this.GridView1.Rows)
            {
                CheckBox chcarid = (CheckBox)row.Cells[0].FindControl("chcarid");
                int id = int.Parse(chcarid.ToolTip);
                if (id == this.carid)
                {
                    DropDownList ddlcats = (DropDownList)row.Cells[7].FindControl("ddlcats");
                    ddlcats.Visible = false;
                    TextBox tbprice = (TextBox)row.Cells[8].FindControl("tbprice");
                    tbprice.Visible = false;
                }
            }
        }
                  
        
    }
    protected void btadd_Click(object sender, EventArgs e)
    {
        List<CarInStore> ls = new List<CarInStore>();
        foreach (GridViewRow row in this.GridView1.Rows)
        {
            CheckBox chcarid = (CheckBox)row.Cells[0].FindControl("chcarid");
            if (chcarid.Checked)
            {
                int carId = int.Parse(row.Cells[1].Text);
                DropDownList ddlcats = (DropDownList)row.Cells[7].FindControl("ddlcats");
                int catId = int.Parse(ddlcats.SelectedValue);
                TextBox tbprice = (TextBox)row.Cells[8].FindControl("tbprice");
                int price = int.Parse(tbprice.Text);
                ls.Add(new CarInStore(carId, price, catId));
            }
        }

        ProductHelper ph = new ProductHelper();
        ph.AddCarsToStore(ls);

    }

    public byte[] ImageToBytes(System.Drawing.Image img)
    {
        ImageConverter converter = new ImageConverter();

        return (byte[])converter.ConvertTo(img, typeof(byte[]));
    }

}