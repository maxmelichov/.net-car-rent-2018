﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

 
public partial class Registraion : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            SetAge();
    }

    private void SetAge()
    {
        for (int i = 18; i <= 80; i++)
        {
            this.DropDownList1.Items.Add(i.ToString());
        }
    }
    protected void tbid_TextChanged(object sender, EventArgs e)
    {

    }
 
    protected void Button1_Click(object sender, EventArgs e)
    {
        string id = this.tbid.Text;
        string custname = this.tbfname.Text;
        string email = this.tbemail.Text;
        string pass = this.tbpass.Text;
        string city = this.tbcity.Text;
        int age = int.Parse (DropDownList1.SelectedValue);

        Customer c = new Customer(id, pass, custname, age, city, email, 1);
        c.InsertCustomer();
        this.lbresult.Text = "Customer Register Successefuly";
        this.lbresult.Visible = true;
        

       
    }
}