﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

  
public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["message"] != null && Request.QueryString["message"] == "1") 
        {
            lberror.Text = "כדי לקבל גישה לדף עליך להירשם ולהתחבר למערכת";
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string id = this.tbid.Text;
        string pass = this.tbpass.Text;
        Dal dal = new Dal();
        Customer c = Customer.GetLoginCustomer(id, pass);
        if (c == null)
        {
            this.lberror.Text = "פרטי כניסה שגויים";

        }

        else
        {
            Session["customer"] = c;
            Response.Redirect("Home.aspx");
        }
    }
}