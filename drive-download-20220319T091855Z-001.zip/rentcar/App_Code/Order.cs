﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.OleDb;
using System.Data;

/// <summary>
/// Summary description for Order
/// </summary>
public class Order
{
    public int OrederId { get; set; }
    public string UserId{ get; set; }
    public int TotalPrice { get; set; }
    public DateTime OrderDate { get; set; }
    public bool Status { get; set; }


    public Order(int orederId, string userId, int totalPrice, DateTime orderDate, bool status)
	{
        this.OrederId = orederId;
        this.UserId = userId;
        this.TotalPrice = totalPrice;
        this.OrderDate = orderDate;
        this.Status = status;
	}

    public Order(string userId, int totalPrice, DateTime orderDate, bool status)
    {
       
        this.UserId = userId;
        this.TotalPrice = totalPrice;
        this.OrderDate = orderDate;
        this.Status = status;
    }

    public void InserOrder(CartData cart)
    {
        string sql = string.Format ("insert into tblorders (userid, totalprice, orderdate, status) values ('{0}', {1}, '{2}', {3})", 
            this.UserId, this.TotalPrice, this.OrderDate.ToShortDateString(), this.Status);

        //2.1 set connection path to db
        Dal dal = new Dal();
        dal.ExecuteNQ(sql);
        InitOrderId();

       DataTable dt = ConvertCartToDT(cart);
       sql = "select * from tblproductsinorder";

       dal.InsertDataTableToDB(sql, dt);
       //FlashDtToDb("tblproductsinorder", dt);




    }


    private void InitOrderId()
    {
        string sql = "SELECT Max(orderid) from tblorders";

        Dal dal = new Dal();

        object val = dal.ExecuteScalar(sql);
        int id = int.Parse(val.ToString());
        this.OrederId = id;
    }

    private DataTable ConvertCartToDT(CartData cart)
    {
        DataTable dt = new DataTable("prodcutInOrder");
        dt.Columns.Add("orderid", typeof(Int32));
        dt.Columns.Add("productid", typeof(Int32));
        dt.Columns.Add("duration", typeof(Int32));
        dt.Columns.Add("fromdate", typeof(DateTime));

        foreach (CarView p in cart.CartProductList)
        {
            DataRow row = dt.NewRow();
            row["orderid"] = this.OrederId;
            row["productid"] = p.Id;
            row["duration"] = p.Duration;
            row["fromdate"] = p.StartDate.ToShortDateString();
            dt.Rows.Add(row);

        }

        return dt;
    }


    //private void FlashDtToDb(string tablename, DataTable dt)
    //{
    //    string dbpath = HttpContext.Current.Server.MapPath("~/App_Data/myDB.accdb");
    //    string conpath = string.Format("Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0}", dbpath);


    //    string sql = "select * from " + tablename;
    //    OleDbConnection con = new OleDbConnection(conpath);
    //    OleDbCommand cmd = new OleDbCommand(sql, con);
    //    OleDbDataAdapter da = new OleDbDataAdapter(cmd);

    //    OleDbCommandBuilder builder = new OleDbCommandBuilder(da);
    //    da.UpdateCommand = builder.GetUpdateCommand();

    //    da.Update(dt);
    //}


    public static DataTable GetAllOrders()
    {

        string sql = "select tblorders.*, tblcustomers.custname from tblorders, tblcustomers where tblcustomers.customerId=tblorders.userid";
        Dal dal = new Dal();
        return dal.GetDataTable(sql);
    }

    public static int GetOrderStatus(int orderId)
    {
        string sql = string.Format ("SELECT status from tblorders where orderid={0}", orderId);

        Dal dal = new Dal();



        object val = dal.ExecuteScalar(sql);
        int status = int.Parse(val.ToString());
        return status;
    }

    public static void SetOrderStatus(int orderId, int newStatus)
    {
        string sql = string.Format("update tblorders set status={0} where orderid={1} ", newStatus, orderId);


        Dal dal = new Dal();


        dal.ExecuteNQ(sql);
       
    }

    public static DataTable GetProductsInOrder(int orderid)
    {
        string sql = string.Format("select tblproducts.pcode, tblproducts.pname, tblcategories.catname, tblproductsinorder.amount from  tblproductsinorder, tblproducts, tblcategories where tblproductsinorder.orderid={0} and tblproductsinorder.productid = tblproducts.pcode and tblproducts.categoryid = tblcategories.catid", orderid);
        Dal dal = new Dal();
        return dal.GetDataTable(sql);


    }
}