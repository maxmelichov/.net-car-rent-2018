﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for Category
/// </summary>
public class Category
{
    public int CCode { get; set; }
    public string Cname { get; set; }
    public string Pic { get; set; }

    public Category(int Code, string name, string pic)
	{
        this.CCode = Code;
        this.Cname = name;
        this.Pic = pic;
	}

    public static Category[] GetAllCategories()
    {
        //1. write SQL command
        string sql = "select * from tblcategories";

        Dal dal = new Dal();


        DataTable dt = dal.GetDataTable(sql);
        Category[] arr = new Category[dt.Rows.Count];
        int index = 0;
        foreach (DataRow row in dt.Rows)
        {
            Category c = new Category(int.Parse(row["catid"].ToString()), row["catname"].ToString(), row["catimg"].ToString());
            arr[index] = c;
            index++;
        }

        return arr;

    }
}