﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for Customer
/// </summary>
public class Customer
{
    private string customerId;
    private string custname;
    private string email;
    private int prem;
    private string custcity;
    private string pass;
    private int age;

    public Customer(string customerId, string password,
     string custname, int age, string city,
     string email,
     int prem)
    {

        this.pass = password;
        this.customerId = customerId;
        this.custname = custname;
        this.email = email;
        this.City = city;
        this.age = age;
        this.prem = prem;
    }


    public string CustomerId
    {
        get
        {
            return this.customerId;
        }

        set
        {
            this.customerId = value;

        }
    }
    //הפעולה מחזירה ומעדכנת את קוד המשתמש
    public string Password
    {
        get
        {
            return this.pass;
        }

        set
        {
            this.pass = value;
        }
    }
    //הפעולה מחזירה ומעדכנת את הסיסמא
    public string CustomerName
    {
        get
        {
            return this.custname;
        }

        set
        {
            this.custname = value;
        }
    }

    public string City
    {
        get
        {
            return this.custcity;
        }

        set
        {
            this.custcity = value;
        }
    }


    //הפעולה מחזירה ומעדכנת את שם הלקוח
    public string Email
    {
        get
        {
            return this.email;
        }

        set
        {
            this.email = value;
        }
    }
    //הפעולה מחזירה ומעדכנת את כתובת האימייל של המשתמש
    public int Prem
    {
        get
        {
            return this.prem;
        }

        set
        {
            this.prem = value;
        }
    }

    public int Age
    {
        get
        {
            return this.age;
        }

        set
        {
            this.age = value;
        }
    }
    //הפעולה מחזירה ומעדכנת את הרשאת המשתמש


    public void InsertCustomer()
    {
        string sql = string.Format("INSERT INTO tblcustomers VALUES ('{0}', '{1}', '{2}', '{3}', {4}, '{5}', {6})", this.customerId, this.Password, this.custname, this.email, this.prem, this.City, this.age);
        Dal dal = new Dal();
        dal.ExecuteNQ(sql);
    }
    //הפעולה מוסיפה לקוח לרשימת הלקוחות
    public static DataTable GetAllCustomers()
    {
        //string sql = string.Format("SELECT * FROM tblcustomers");
        //Dal dal = new Dal();
        //return dal.GetDataTable(sql);

        //הפעולה מחזירה את כל הלקוחות שיש במאגר המידע של החנות
        return null;
    }
     

    public static Customer GetLoginCustomer(string username, string password)
    {
        Customer c = null;
        string sql = string.Format("SELECT * FROM tblcustomers WHERE customerId='{0}' AND custpass='{1}'", username, password);
        Dal dal = new Dal();
        DataTable dt = dal.GetDataTable(sql);
        if (dt != null && dt.Rows.Count > 0)
        {
            DataRow row = dt.Rows[0];
            string customerId = row["customerId"].ToString();
            string pass = row["custpass"].ToString();
            string custname = row["custname"].ToString();
            string city = row["custcity"].ToString();
            int age =  int.Parse(row["age"].ToString());
            string email = row["custemail"].ToString();
            int prem = int.Parse(row["prem"].ToString());
            c = new Customer(customerId, pass, custname, age, city, email, prem);

        }

        return c ;

    }

    
}