﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for ProductInCart
/// </summary>
public class ProductInCart : CarInStore
{
    public int Amount { get; set; }
    private int totalPriceInCart;

	public ProductInCart(int pCode, string pname, int price, string category, int stock, string pic, int amount) : 
        base (pCode, pname, price, category, pic)
	{
        this.Amount = amount;
	}

    public ProductInCart(CarInStore p, int amount) :
        base(p.PCode, p.Pname, p.Price, p.Category, p.Pic)
    {
        this.Amount = amount;
    }

    public int TotalPriceInCart
    {
        get
        {
            return this.Price * this.Amount;
        }
    }
}