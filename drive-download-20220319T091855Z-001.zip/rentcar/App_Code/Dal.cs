﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.OleDb;
using System.Data;
using System.Data.SqlClient;


/// <summary>
/// Summary description for Dal
/// </summary>
public class Dal
{
    private OleDbConnection con;
    private OleDbCommand cmd;
    private OleDbDataAdapter da;
	public Dal()
	{
        this.con = new OleDbConnection(GetConnectionStr());
	}

    private static string GetConnectionStr()
    {
        string dbpath = HttpContext.Current.Server.MapPath("~/App_Data/dbCars.accdb");
        string conStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + dbpath;
        return conStr;
    }
   
    public void ExecuteNQ(string sql)
    {
        this.cmd = new OleDbCommand(sql, this.con);
        this.con.Open();
        this.cmd.ExecuteNonQuery();
        this.con.Close();


    }


    //הפעולה מחזירה את המשתמש המחובר 
    public bool ExcuteNonQuery(string sql)
    {
        
        OleDbCommand cmd = null;
        bool flag = false;
        try
        {
            
            cmd = new OleDbCommand(sql, this.con);
            con.Open();
            int numOfUpdateRows = cmd.ExecuteNonQuery();
            if (numOfUpdateRows > 0)
                flag = true;


        }

        catch (Exception e)
        {
            flag = false;
        }

        con.Close();

        return flag;

    }
    

    public object ExecuteScalar(string sql)
    {
      
        OleDbCommand cmd = null;
        object val = null;
        try
        {

            cmd = new OleDbCommand(sql, this.con);
            con.Open();
            val = cmd.ExecuteScalar();
            con.Close();
        }

        catch (Exception e)
        {
            val = null;
        }

        con.Close();

        return val;

    }
    //הפעולה מחזירה ערך יחיד ממאגר המידע
    public DataTable GetDataTable(string sql)
    {
        this.da = new OleDbDataAdapter(sql, this.con);
        DataSet ds = new DataSet();
        this.da.Fill(ds);
        return ds.Tables[0];
    }
//  הפעולה מחזירה טבלה
    public DataTable GetDataTable(string sql, string paramName1, string paramName2, int paramVal1, int paramVal2)
    {
        this.cmd = new OleDbCommand(sql, this.con);
        this.cmd.Parameters.Add(paramName1, SqlDbType.Int);
        this.cmd.Parameters[paramName1].Value = paramVal1;
        this.cmd.Parameters.Add(paramName2, SqlDbType.Int);
        this.cmd.Parameters[paramName2].Value = paramVal2;

        this.da = new OleDbDataAdapter(this.cmd);
        DataSet ds = new DataSet();
        this.da.Fill(ds);
        return ds.Tables[0];

    }
    //הפעולה מחזירה טבלה ממאגר הנתונים
    public bool InsertDataTableToDB(string sql, DataTable dt)
    {


        
        OleDbCommand cmd = new OleDbCommand(sql, this.con);
        OleDbDataAdapter da = new OleDbDataAdapter(cmd);

        OleDbCommandBuilder bulider = new OleDbCommandBuilder(da);

        da.UpdateCommand = bulider.GetUpdateCommand();

        da.Update(dt);


        return true;
    }

    
    //הפעולה מוסיפה טבלה של לקוחות
}