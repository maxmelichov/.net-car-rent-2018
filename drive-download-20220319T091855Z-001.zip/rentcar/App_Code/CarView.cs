﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for CarView
/// </summary>
public class CarView
{
    public int Id { get; set; }
    public string Producer { get; set; }
    public string Model { get; set; }
    public int Year { get; set; }
    public bool Available { get; set; }
    public byte[] Image { get; set; }
    public string Category { get; set; }
    public int Price { get; set; }
    public DateTime StartDate { get; set; }
    public int Duration { get; set; }

	public CarView()
	{
		
	}


    public static CarView[] GetAllProducts(int catId)
    {
         string sql = "";
        if (catId == -999)
             sql = "select tblproducts.*, tblcategories.catname from tblproducts, tblcategories where tblproducts.categoryid = tblcategories.catid";
        else
            sql = "select tblproducts.*, tblcategories.catname from tblproducts, tblcategories where tblproducts.categoryid = tblcategories.catid and tblcategories.catid=" + catId;

        return GetViews(sql);

    }

    private static CarView[] GetViews(string sql)
    {
        Dal dal = new Dal();

        CarAreaService.AreaService service = new CarAreaService.AreaService();
        DataTable dt = dal.GetDataTable(sql);
        CarView[] arr = new CarView[dt.Rows.Count];
        int index = 0;
        foreach (DataRow row in dt.Rows)
        {
            int carid = int.Parse(row["pcode"].ToString());
            CarAreaService.Car car = service.GetCarInfo(carid);
            CarView view = new CarView();
            view.Id = carid;
            view.Category = row["catname"].ToString();
            view.Producer = car.Producer;
            view.Model = car.Model;
            view.Available = car.Available;
            view.Year = car.Year;
            view.Image = car.Image;
            view.Price = int.Parse(row["price"].ToString());

            arr[index] = view;
            index++;
        }

        return arr;
    }

    public static CarView GetProductsByCarId(int carid)
    {
        //1. write SQL command
        string sql = "select tblproducts.*, tblcategories.catname from tblproducts, tblcategories where tblproducts.categoryid = tblcategories.catid and pcode=" + carid;

        Dal dal = new Dal();

        CarAreaService.AreaService service = new CarAreaService.AreaService();
        DataTable dt = dal.GetDataTable(sql);

        DataRow row = dt.Rows[0];
       
        
        CarAreaService.Car car = service.GetCarInfo(carid);
        CarView view = new CarView();
        view.Id = carid;
        view.Category = row["catname"].ToString();
        view.Producer = car.Producer;
        view.Model = car.Model;
        view.Available = car.Available;
        view.Year = car.Year;
        view.Image = car.Image;
        view.Price = int.Parse(row["price"].ToString());

       
        return view;

    }
}