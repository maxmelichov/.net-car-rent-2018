﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for CartData
/// </summary>
public class CartData
{
    public List<CarView> CartProductList { get; set; }
    public CartData(List<CarView> ls)
	{
        this.CartProductList = ls;
	}


    public CarView SearchInCart(int pcode)
    {
        foreach (CarView p in this.CartProductList)
        {
            if (p.Id == pcode)
                return p;
        }

        return null;
    }

    public void UpdateCarDuration(int carId, int duration)
    {
        CarView cv = SearchInCart(carId);

        cv.Duration = duration;
    }//טענת כניסה:מכבל אינדקס של מוצר וכמות לעדכון
    //טענת יציאה: מעדכן את הכמות של המוצר הנתון


    public void DeleteFromCart(int pcode)
    {
        CarView p = SearchInCart(pcode);
        if (p != null)
            this.CartProductList.Remove(p);
            
    }



    public void InsertToCart(CarView toAdd)
    {
        CarView p = SearchInCart(toAdd.Id);
        
        this.CartProductList.Add(toAdd);
    }

    public int TotalPrice()
    {
        int sum = 0;
        foreach (CarView p in this.CartProductList)
        {
            sum += p.Price * p.Duration;
        }

        return sum;
    }
}