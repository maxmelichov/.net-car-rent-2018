﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.OleDb;
using System.Data;

/// <summary>
/// Summary description for Product
/// </summary>
public class CarInStore
{
    public int PCode { get; set; }
    public string Pname { get; set; }
    public int Price { get; set; }
    public string Category { get; set; }
    public int CategoryId { get; set; }
    public string Pic { get; set; }
    public byte [] PicBtyte { get; set; }
    public string Model { get; set; }
    public int Year { get; set; }


    public CarInStore(int pCode, int price, int category)
    {
        this.PCode = pCode;
        this.Price = price;
        this.CategoryId = category;
    }
    public CarInStore(int pCode, string pname, int price, string category, string pic)
	{

        this.PCode = pCode;
        this.Pname = pname;
        this.Pic = pic;
        this.Price = price;
        this.Category = category;

	}

    public CarInStore(int pCode, string pname, int price, int category, byte [] pic)
    {

        this.PCode = pCode;
        this.Pname = pname;
        this.PicBtyte = pic;
       
        this.Price = price;
        this.CategoryId = category;

    }


   
    //public static CarInStore GetProductFromDB(int pcode)
    //{
    //    //1. write SQL command
    //    string sql = string.Format("select tblproducts.*, tblcategories.catname from tblproducts, tblcategories where pcode={0} and tblproducts.categoryid = tblcategories.catid", pcode);

    //    Dal dal = new Dal();



    //    DataTable dt = dal.GetDataTable(sql);

    //    DataRow row = dt.Rows[0];

    //    CarInStore p = new CarInStore(pcode, row["pname"].ToString(), int.Parse(row["price"].ToString()), row["catname"].ToString(), int.Parse(row["stock"].ToString()), row["pic"].ToString());

    //    return p;

    //}

    

    //public static CarInStore[] GetAllProductsByCat(int catId)
    //{
    //    //1. write SQL command
    //    string sql = "select tblproducts.*, tblcategories.catname from tblproducts, tblcategories where tblproducts.categoryid = tblcategories.catid and tblcategories.catid=" + catId;

    //    Dal dal = new Dal();


    //    DataTable dt = dal.GetDataTable(sql);
    //    CarInStore[] arr = new CarInStore[dt.Rows.Count];
    //    int index = 0;
    //    foreach (DataRow row in dt.Rows)
    //    {
    //        CarInStore p = new CarInStore(int.Parse(row["pcode"].ToString()), row["pname"].ToString(), int.Parse(row["price"].ToString()), row["catname"].ToString(), int.Parse(row["stock"].ToString()), row["pic"].ToString());
    //        arr[index] = p;
    //        index++;
    //    }

    //    return arr;

    //}
}