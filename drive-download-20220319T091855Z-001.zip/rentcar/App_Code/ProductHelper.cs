﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for ProductHelper
/// </summary>
public class ProductHelper
{
	public ProductHelper()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public  void AddCarsToStore(List<CarInStore> ls)
    {
        DataTable dt = ConvertCartToDT(ls);
        Dal dal = new Dal();
        string sql = "select * from tblproducts";
        dal.InsertDataTableToDB(sql, dt);
    }

   
    private DataTable ConvertCartToDT(List<CarInStore> ls)
    {
        DataTable dt = new DataTable("tblproducts");
        dt.Columns.Add("pcode", typeof(Int32));
        dt.Columns.Add("price", typeof(Int32));
        dt.Columns.Add("categoryid", typeof(Int32));

        foreach (CarInStore c in ls)
        {
            DataRow row = dt.NewRow();
            row["pcode"] = c.PCode;
            row["price"] = c.Price;
            row["categoryid"] = c.CategoryId;
            dt.Rows.Add(row);

        }
        return dt;
    }
}