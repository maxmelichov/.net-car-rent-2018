﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class ManageOrders : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
        LoadGV();
        



    }

    private void LoadGV()
    {


        this.GridView1.DataSource = Order.GetAllOrders();
        this.GridView1.DataBind();

        

    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType != DataControlRowType.Header &&
           e.Row.RowType != DataControlRowType.Footer &&
           e.Row.RowType != DataControlRowType.Pager)
        {
            if (e.Row.RowState != (DataControlRowState.Edit | DataControlRowState.Alternate)
                && e.Row.RowState != (DataControlRowState.Edit | DataControlRowState.Normal))
            {
                ImageButton ib = e.Row.Cells[0].Controls[0] as ImageButton;
                RadioButtonList rbl = e.Row.Cells[6].FindControl("approve") as RadioButtonList;
                
                int orderId = int.Parse (e.Row.Cells[1].Text);
                rbl.ID = orderId.ToString();
                int status = Order.GetOrderStatus(orderId);
                switch (status)
                {
                    case 1:
                        ib.ImageUrl = "~/pics/system/confirm.jpg";
                        rbl.Items[0].Selected = true;
                        rbl.Enabled = false;
                        break;
                    case 2:
                        ib.ImageUrl = "~/pics/system/notconf.jpg";
                        rbl.Items[1].Selected = true;
                        rbl.Enabled = false;
                        break;
                }


            }
        }
    }
    protected void approve_SelectedIndexChanged(object sender, EventArgs e)
    {
        RadioButtonList rbl = sender as RadioButtonList;
        int val = int.Parse(rbl.SelectedValue);
        int orderId = int.Parse(rbl.ID);
        switch (val)
        {
            case 0:
                Order.SetOrderStatus(orderId, 2);
                break;
            case 1:
                Order.SetOrderStatus(orderId, 1);
                break;
        }

        LoadGV();
    }
    protected void GridView1_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {
        GridViewRow row = this.GridView1.Rows[e.NewSelectedIndex];
        int orderid = int.Parse(row.Cells[1].Text);
        DataTable dt = Order.GetProductsInOrder(orderid);
        this.GridView2.DataSource = dt;
        this.GridView2.DataBind();
        this.Panel1.Visible = true;


    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        this.Panel1.Visible = false;
    }
}