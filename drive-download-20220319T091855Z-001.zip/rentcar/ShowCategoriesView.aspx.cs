﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class ShowCategoriesView : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            LoadDataList();
            

        }

    }

    private void LoadDataList()
    {
        
        
        this.DataList1.DataSource = Category.GetAllCategories();
        this.DataList1.DataBind();
    }

    protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataListItem item = this.DataList1.SelectedItem;

        Label lbcatid = item.FindControl("lbcatid") as Label;
        int catid = int.Parse(lbcatid.Text);
        Response.Redirect("Store-1.aspx?catid=" + catid);

    }
}