﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;


public partial class Store_1 : System.Web.UI.Page
{
    private CartData cart;
    private CarView[] cars;
    private int index = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
     
            if (!IsPostBack)
            {
                if (Request["catid"] != null)
                    LoadDataList(int.Parse(Request["catid"]));
                else
                    LoadDataList(-999);
                if (Session["sal"] == null)
                    Session["sal"] = new CartData(new List<CarView>());



                this.cart = Session["sal"] as CartData;


            }
             
            
        
    }
            
        
       

            private void LoadDataList(int cat)
            {
                this.cars = CarView.GetAllProducts(cat);
                this.DataList1.DataSource = this.cars;
                this.DataList1.DataBind();
            }
            protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
            {
                    DataListItem item = this.DataList1.SelectedItem;

                    Label lbCode = item.FindControl("lbcode") as Label;
                    int code = int.Parse(lbCode.Text);
                    CarView p = CarView.GetProductsByCarId(code);
                    Session["peakCar"] = p;
                    Response.Redirect("PeakDates.aspx");
                    //this.cart.InsertToCart(p);
                


            }
            protected void LinkButton1_Click(object sender, EventArgs e)
            {

            }
            protected void DataList1_ItemDataBound(object sender, DataListItemEventArgs e)
            {
                CarView view = this.cars[this.index];
                Image carpoic = e.Item.FindControl("imgpic") as Image;

                string base64String = Convert.ToBase64String(view.Image, 0, view.Image.Length);

                carpoic.ImageUrl = "data:image/jpeg;base64," + base64String;
                this.index++;

            }
        }
    