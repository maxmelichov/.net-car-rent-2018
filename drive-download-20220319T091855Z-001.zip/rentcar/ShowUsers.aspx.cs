﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

public partial class ShowUsers : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            InitView();
        }
    }

    private void InitView()
    {
        //1. write SQL command
        string sql = "select * from tblcustomers";

        //2. go to db
        //2.1 set connection path to db
        string dbpath = Server.MapPath("~/App_Data/dbCars.accdb");
        string conpath = string.Format ("Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0}", dbpath);

        //2.2 int con object with path we found
        OleDbConnection con = new OleDbConnection(conpath);

        OleDbDataAdapter da = new OleDbDataAdapter(sql, con);

        DataSet ds = new DataSet();

        da.Fill(ds);

        DataTable dt = ds.Tables[0];
        Session["userTable"] = dt;

        this.GridView1.DataSource = dt;
        this.GridView1.DataBind();




    }
    protected void GridView1_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {
        this.Panel1.Visible = true;
        DataTable dt = Session["userTable"] as DataTable;
        int rowIndex = e.NewSelectedIndex;
        DataRow row = dt.Rows[rowIndex];
        this.TextBox1.Text = row["userpass"].ToString();
        bool isAdmin = bool.Parse(row["admin"].ToString());
        this.CheckBox1.Checked = isAdmin;               
    }


    protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
    {
       
    }


    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        GridViewRow row =  this.GridView1.Rows[e.RowIndex];
        string userId = row.Cells[1].Text;

        string sql = string.Format("delete from tblcustomers where customerId ='{0}'", userId);
        Dal dal = new Dal();
        dal.ExcuteNonQuery(sql);
        InitView();        

    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        this.GridView1.EditIndex = e.NewEditIndex;
        InitView();
    }
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        this.GridView1.EditIndex = -1;
        InitView();

    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        GridViewRow row = this.GridView1.Rows[e.RowIndex];
        string id = row.Cells[1].Text;
        string name = ((row.Cells[2].Controls[0]) as TextBox).Text;
        string email = ((row.Cells[3].Controls[0]) as TextBox).Text;
        string city = ((row.Cells[4].Controls[0]) as TextBox).Text;
       
       
        string age = ((row.Cells[5].Controls[0]) as TextBox).Text;
        string pass = ((row.Cells[6].Controls[0]) as TextBox).Text;

        string sql = string.Format("update tblcustomers set custpass='{0}', custname='{1}', custemail='{2}', age={3}, custcity='{4}' where customerId='{5}'", pass,name, email, age,city, id);
        Dal dal = new Dal();
        dal.ExcuteNonQuery(sql);

        this.GridView1.EditIndex = -1;
        InitView();

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}