﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Cart : System.Web.UI.Page
{
    private CartData cart;
    protected void Page_Load(object sender, EventArgs e)
    {
        this.cart = Session["sal"] as CartData;
        if (!IsPostBack)
            LoadGV();
        
    }

    private void LoadGV()
    {
      

        this.GridView1.DataSource = cart.CartProductList;
        this.GridView1.DataBind();

        this.Label2.Text = "Total Price for Cart: " + cart.TotalPrice();

    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        this.GridView1.EditIndex = e.NewEditIndex;
        LoadGV();

    }
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        this.GridView1.EditIndex = -1;
        LoadGV();
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        int index = e.RowIndex;
        GridViewRow row = this.GridView1.Rows[index];
        int pcode = int.Parse (row.Cells[1].Text);
        CartData cart = Session["sal"] as CartData;
        cart.DeleteFromCart(pcode);
        LoadGV();

    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {

        GridViewRow row = this.GridView1.Rows[e.RowIndex];
        int carid = int.Parse(row.Cells[1].Text);
        int duration = int.Parse(((TextBox)row.Cells[7].Controls[0]).Text);
        CartData bag = (CartData)Session["sal"];
        bag.UpdateCarDuration(carid, duration);
        
        this.GridView1.EditIndex = -1;
        LoadGV();

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Customer c = Session["customer"] as Customer;
        Order o = new Order(c.CustomerId, this.cart.TotalPrice(), DateTime.Now, false);
        o.InserOrder(this.cart);
        lbresult.Visible = true;
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }
}