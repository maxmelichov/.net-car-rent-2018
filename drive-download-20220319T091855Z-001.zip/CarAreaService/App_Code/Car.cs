﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Car
/// </summary>
public class Car
{
    public int Id { get; set; }
    public string Producer { get; set; }
    public string Model { get; set; }
    public int Year { get; set; }
    public bool Available { get; set; }
    public byte[] Image { get; set; }

	public Car()
	{
		
	}
}