﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data;
using System.IO;
using System.Drawing;
using System.Globalization;

/// <summary>
/// Summary description for AreaService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class AreaService : System.Web.Services.WebService {

    public AreaService () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public Car[] GetAllCarsInfo() {
        string sql = "Select * from tblcars";
        Dal dal = new Dal();
        DataTable dt = dal.GetDataTable(sql);
        List<Car> cars = new List<Car>();
       
        foreach (DataRow row in dt.Rows)
        {
            Car c = new Car();
            c.Id = int.Parse (row[0].ToString());
            c.Producer = row[1].ToString();
            c.Model = row[2].ToString();
            c.Year = int.Parse(row[3].ToString());
            c.Available = bool.Parse(row[4].ToString());
            Image img = Image.FromFile(string.Format(HttpContext.Current.Server.MapPath("~/pic/cars/{0}"), row[5].ToString()));
            MemoryStream ms = new MemoryStream();
            img.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
            c.Image = ms.ToArray();
            if (c.Available)
            {
                cars.Add(c);
                
            }
        }

        return cars.ToArray();

    }

    [WebMethod]
    public Car GetCarInfo(int carid) {
        string sql = "Select * from tblcars where carid = " + carid;
        Dal dal = new Dal();
        DataTable dt = dal.GetDataTable(sql);
        DataRow row = dt.Rows[0];
        Car c = new Car();
        c.Id = int.Parse(row[0].ToString());
        c.Producer = row[1].ToString();
        c.Model = row[2].ToString();
        c.Year = int.Parse(row[3].ToString());
        c.Available = bool.Parse(row[4].ToString());
        Image img = Image.FromFile(string.Format(HttpContext.Current.Server.MapPath("~/pic/cars/{0}"), row[5].ToString()));
        MemoryStream ms = new MemoryStream();
        img.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
        c.Image = ms.ToArray();
        return c;
    }

    [WebMethod]
    public bool IsCarAvailableToRent(int carid, DateTime startDate, int duration) {
        DateTime end = startDate.AddDays(duration);
        string sql = string.Format("SELECT carid from tblcarordes where carid={0} and startdate <= #{1}#",
         carid,
         DateTime.ParseExact(end.ToShortDateString(), "dd/MM/yyyy", CultureInfo.InvariantCulture).ToShortDateString());

        Dal dal = new Dal();
        object o = dal.ExecuteScalar(sql);
        bool res = o != null ? false : true;
        return res;

    }
    
}
